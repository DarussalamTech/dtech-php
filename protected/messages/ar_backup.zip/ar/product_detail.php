<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$product_detail_t = array(
    "Book Description" => "وصف الكتاب",
    "Most Recent Customer Reviews" => "معظم الزوار آراء العملاء",
);
return $product_detail_t;
?>
